%%     Robustness to parameter uncertanties

PARAMETERS_AC = PARAMETERS_AC_MONTECARLO; % to re use the other script
omega_true = OMEGA_MONTECARLO;

sim (model_name)
hold on
