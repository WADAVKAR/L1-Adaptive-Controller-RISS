function NewFigureHide()
h = figure;
set(h, 'Visible', 'off');
end
